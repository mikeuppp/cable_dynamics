% cd to mooring
cd c:\apps\matlab\toolbox\local\mooring
%